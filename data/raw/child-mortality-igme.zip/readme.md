# Child mortality rate - Data package

This data package contains the data that powers the chart ["Child mortality rate"](https://ourworldindata.org/grapher/child-mortality-igme?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on November 6, 2026.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV structure

Each row is an observation for an entity (usually a country or region) at a timepoint.

- "Entity" — the name of the entity, e.g. "United States".
- "Code" — our internal entity code. For most countries this is the [ISO alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code, e.g. "USA"; historical and other non-standard entities get a custom code.
- "Year" or "Day" — the timepoint. Annual data has a "Year" column holding an integer year; otherwise a "Day" column holds a date string in the form "YYYY-MM-DD".
- The final column is the data column — the time series that powers the chart. Downloaded with the "full data" option it corresponds to the time series below; with "only selected data visible in the chart" it is transformed depending on the chart type, so the correspondence may be less direct.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc.

## How we process data at Our World in Data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stitch together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

Preparing this data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/).

## Detailed information about the data


### Child mortality rate – UN IGME
Estimated number of deaths of children aged under five years, per 100 live births .
Last updated: June 9, 2026  
Next expected update: June 2027  
Date range: 1931–2024  
Unit: deaths per 100 live births  
Source: United Nations Inter-agency Group for Child Mortality Estimation (2025) – processed by Our World in Data  

#### How to cite this data

United Nations Inter-agency Group for Child Mortality Estimation (2025) – processed by Our World in Data

#### What you should know about this data
In countries hit by a humanitarian crisis, the UN IGME fits its trend with the crisis years set aside and then adds the crisis deaths back, so a few countries show a sharp one-year spike: Rwanda in 1994, Somalia in 2011, the Central African Republic in 2009, 2019 and 2022. For the Central African Republic these come from mortality surveys compiled by [Gang et al. (2023)](https://doi.org/10.1186/s13031-023-00514-z). They are all-cause excess deaths, added for the years each survey was run rather than spread across the longer period the surveys point to.

#### Notes on our processing step for this indicator
Aggregate measures for continents are calculated by Our World in Data, using our definition of the continents found [here](https://ourworldindata.org/world-region-map-definitions#our-world-in-data).

We do this by calculating a weighted average from the national rates, using the respective denominators (e.g. live births or children under 5) as weights.


## Sources

These are the sources behind the data in this package. Each time series above names the ones it draws on in its citation.

### United Nations Inter-agency Group for Child Mortality Estimation

The United Nations Inter-agency Group for Child Mortality Estimation (UN IGME) was formed in 2004 to share data on child mortality, improve methods for child mortality estimation, report on progress towards child survival goals, and enhance country capacity to produce timely and properly assessed estimates of child mortality. The UN IGME is led by the United Nations Children’s Fund (UNICEF) and includes the World Health Organization (WHO), the World Bank Group and the United Nations Population Division of the Department of Economic and Social Affairs as full members.

UN IGME updates its child mortality estimates annually after reviewing newly available data and assessing data quality. The web portal contains the latest UN IGME estimates of child mortality at the country, regional and global levels, and the data used to derive them.

Producer: United Nations Inter-agency Group for Child Mortality Estimation  
Published: 2026-03-17  
Retrieved on: 2026-06-09  
Retrieved from: https://childmortality.org/all-cause-mortality/data  
Direct download: https://childmortality.org/wp-content/uploads/2026/03/UN-IGME-2025.zip  
License: Copyright © UNICEF (https://www.unicef.org/legal#copyright)  

Citation: United Nations Inter-agency Group for Child Mortality Estimation (2026).

    